#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RSVG -> JSONL exporter (normalized coordinates, subsampling, controllable thinking)
- Use DIOR_RSVG/{split}.txt to filter global object indices
- Subsampling: default export only 1/10 of original dataset
- Parse each <object> in XML, extract [x1, y1, x2, y2], normalize to [0,1]
- problem field: fixed template + thinking control instructions:
    1) You must restrict your thinking within {W} words (W sampled in [--think-words-min, --think-words-max])
    2) You must include the word 'wait' {K} times in your thinking (K sampled in [--wait-min, --wait-max])
    3) Your thinking must start with one opening sentence sampled from THINK_OPENINGS
- answer field (== ground_truth in your pipeline): a dict containing
    {
      "bbox": [x1, y1, x2, y2],     # normalized floats in [0,1]
      "think_words": W,             # int
      "wait_repeats": K,            # int
      "think_opening": O            # str
    }
- images field: absolute path(s) to image

Dependencies:
  pip install pillow tqdm
"""

import argparse
import json
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import random

from PIL import Image as PILImage
from tqdm import tqdm

# ------------------------- Opening sentences for thinking -------------------------
THINK_OPENINGS: List[str] = [
    "Let me think step by step.",
    "I will carefully reason this out.",
    "Let me start analyzing the problem.",
    "I will go through this systematically.",
    "Let me break down the steps clearly.",
    "I will first recall the key details.",
    "Let me reason about this carefully.",
    "I will organize my thoughts step by step.",
    "Let me try to explain my reasoning clearly.",
    "I will proceed with a structured line of thought.",
]

# ------------------------- Utilities -------------------------

def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def read_split_indices(splits_dir: Path, split: str) -> set:
    """Read DIOR_RSVG/{split}.txt (global object indices)."""
    split_file = splits_dir / f"{split}.txt"
    with open(split_file, "r", encoding="utf-8") as f:
        return {int(line.strip()) for line in f if line.strip()}


def list_xmls(anno_path: Path) -> List[Path]:
    """List all XML files (sorted for determinism)."""
    return sorted([p for p in anno_path.rglob("*.xml")])


def parse_bbox(member: ET.Element) -> Optional[Tuple[int, int, int, int]]:
    """Parse bbox from <object>, return (x1, y1, x2, y2)."""
    bnd = member.find("bndbox")
    if bnd is not None:
        try:
            xmin = int(float(bnd.find("xmin").text))
            ymin = int(float(bnd.find("ymin").text))
            xmax = int(float(bnd.find("xmax").text))
            ymax = int(float(bnd.find("ymax").text))
            return xmin, ymin, xmax, ymax
        except Exception:
            pass
    try:
        cand = member[2]
        vals = [int(float(cand[i].text)) for i in range(4)]
        return vals[0], vals[1], vals[2], vals[3]
    except Exception:
        return None


def parse_phrase(member: ET.Element) -> Optional[str]:
    """Parse phrase string from <object>."""
    for tag in ["content", "phrase", "text", "description", "name"]:
        node = member.find(tag)
        if node is not None and node.text:
            return node.text.strip()
    try:
        if len(member) >= 4 and member[3].text:
            return member[3].text.strip()
    except Exception:
        pass
    return None


def image_filename_from_root(root: ET.Element) -> Optional[str]:
    node = root.find("./filename")
    if node is not None and node.text:
        return node.text.strip()
    return None


def export_or_link_image(src_path: Path, dst_dir: Path, copy_images: bool) -> str:
    """Return absolute path string for training image."""
    if not copy_images:
        return src_path.resolve().as_posix()
    ensure_dir(dst_dir)
    dst_path = dst_dir / src_path.name
    if not dst_path.exists():
        shutil.copy2(src_path, dst_path)
    return dst_path.resolve().as_posix()


def get_image_wh(img_path: Path) -> Tuple[int, int]:
    with PILImage.open(img_path) as im:
        w, h = im.size
    if w <= 0 or h <= 0:
        raise ValueError(f"Invalid image size for {img_path}: {w}x{h}")
    return w, h

# ------------------------- Collect objects -------------------------

def iterate_objects(xml_paths: List[Path], images_root: Path) -> Tuple[int, List[Dict]]:
    """Iterate over XML <object>, return (total_objects, record list)."""
    global_count = 0
    records: List[Dict] = []
    for xml_path in tqdm(xml_paths, desc="Scanning XMLs"):
        try:
            root = ET.parse(xml_path).getroot()
        except Exception:
            continue

        fname = image_filename_from_root(root)
        if not fname:
            continue

        img_path = images_root / fname

        for member in root.findall("object"):
            bbox = parse_bbox(member)
            phrase = parse_phrase(member)
            records.append({
                "global_idx": global_count,
                "img_path": img_path,
                "bbox": bbox,
                "phrase": phrase,
            })
            global_count += 1

    return global_count, records

# ------------------------- Subsampling -------------------------

def sample_indices(indices: set, ratio: float, seed: int = 42, mode: str = "random") -> set:
    idx_list = sorted(indices)
    n = len(idx_list)
    if n == 0 or ratio >= 1.0:
        return set(idx_list)
    if ratio <= 0.0:
        raise ValueError("sample-ratio must be > 0.")
    k = max(1, int(n * ratio))
    if mode == "stride":
        step = max(1, round(n / k))
        sampled = idx_list[::step][:k]
    else:
        rng = random.Random(seed)
        sampled = rng.sample(idx_list, k)
    return set(sampled)

# ------------------------- Conversion -------------------------

def convert_split(
    records: List[Dict],
    indices: set,
    out_jsonl: Path,
    copy_images: bool,
    copy_dir: Path,
    decimals: int = 6,
    *,
    think_words_min: int = 64,
    think_words_max: int = 128,
    wait_min: int = 1,
    wait_max: int = 5,
    rng: Optional[random.Random] = None,
) -> int:
    ensure_dir(out_jsonl.parent)
    if rng is None:
        rng = random.Random(0)

    think_words_min = max(1, int(think_words_min))
    think_words_max = max(think_words_min, int(think_words_max))
    wait_min = max(1, int(wait_min))
    wait_max = max(wait_min, int(wait_max))

    kept = 0
    with open(out_jsonl, "w", encoding="utf-8") as f:
        for rec in records:
            if rec["global_idx"] not in indices:
                continue
            img_path: Path = rec["img_path"]
            if not img_path.exists():
                continue
            img_abs = export_or_link_image(img_path, copy_dir, copy_images)
            try:
                w, h = get_image_wh(img_path)
            except Exception:
                continue

            phrase = (rec["phrase"] or "").lower()
            bbox = rec["bbox"]
            if bbox is None:
                continue

            x1, y1, x2, y2 = bbox
            if x2 < x1:
                x1, x2 = x2, x1
            if y2 < y1:
                y1, y2 = y2, y1
            x1 = max(0, min(x1, w))
            x2 = max(0, min(x2, w))
            y1 = max(0, min(y1, h))
            y2 = max(0, min(y2, h))

            bx = [x1/float(w), y1/float(h), x2/float(w), y2/float(h)]
            bx = [max(0.0, min(1.0, v)) for v in bx]
            if decimals is not None and decimals >= 0:
                bx = [round(v, decimals) for v in bx]

            # Random control values
            W = rng.randint(think_words_min, think_words_max)
            K = rng.randint(wait_min, wait_max)
            O = rng.choice(THINK_OPENINGS)

            # Problem string
            problem_core = (
                f"<image> What are the normalized bounding box coordinates "
                f"(x1, y1, x2, y2; values in [0,1]) for '{phrase}'?"
            )
            control_str = (
                f" You must restrict your thinking within {W} words."
                f" You must include the word 'wait' {K} times in your thinking."
                f" Your thinking must start with the following sentence: '{O}'"
            )
            problem = (problem_core + control_str).strip()

            # IMPORTANT: pack bbox + thinking controls into answer (ground_truth)
            obj = {
                "problem": problem,
                "answer": {
                    "bbox": bx,              # <-- used by reward for IoU/center
                    "think_words": W,        # <-- passed via ground_truth
                    "wait_repeats": K,       # <--
                    "think_opening": O,      # <--
                },
                "images": [img_abs],
            }
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")
            kept += 1
    return kept

# ------------------------- CLI -------------------------

def main():
    parser = argparse.ArgumentParser(description="Export RSVG to JSONL with normalized boxes and controllable thinking instructions (packed in answer).")
    parser.add_argument("--images", required=True, help="Root directory of images (matched with <filename> in XML)")
    parser.add_argument("--annos", required=True, help="Annotations root directory (with .xml files)")
    parser.add_argument("--splits", required=True, help="Directory containing train.txt / test.txt (DIOR_RSVG style)")
    parser.add_argument("--out", required=True, help="Output directory")
    parser.add_argument("--copy-images", action="store_true",
                        help="Copy images to output directory (default: link original absolute path)")
    parser.add_argument("--decimals", type=int, default=6,
                        help="Number of decimals for normalized coordinates (default=6, negative to disable rounding)")
    parser.add_argument("--sample-ratio", type=float, default=0.1,
                        help="Subsampling ratio (default=0.1, i.e. 1/10)")
    parser.add_argument("--sample-seed", type=int, default=42,
                        help="Random seed for sampling (default=42)")
    parser.add_argument("--sample-mode", type=str, default="random", choices=["random", "stride"],
                        help="Sampling mode: random/stride (default random)")
    parser.add_argument("--think-words-min", type=int, default=64,
                        help="Minimum words for thinking length (default=64)")
    parser.add_argument("--think-words-max", type=int, default=256,
                        help="Maximum words for thinking length (default=256)")
    parser.add_argument("--wait-min", type=int, default=1,
                        help="Minimum number of 'wait' occurrences (default=1)")
    parser.add_argument("--wait-max", type=int, default=5,
                        help="Maximum number of 'wait' occurrences (default=5)")
    parser.add_argument("--control-seed", type=int, default=None,
                        help="Random seed for control instructions (default reuse sample-seed)")
    args = parser.parse_args()

    if args.think_words_min < 1:
        args.think_words_min = 1
    if args.think_words_max < args.think_words_min:
        args.think_words_max = args.think_words_min
    if args.wait_min < 1:
        args.wait_min = 1
    if args.wait_max < args.wait_min:
        args.wait_max = args.wait_min
    control_seed = args.control_seed if args.control_seed is not None else args.sample_seed
    ctrl_rng = random.Random(control_seed)

    images_root = Path(args.images).expanduser().resolve()
    anno_root = Path(args.annos).expanduser().resolve()
    splits_dir = Path(args.splits).expanduser().resolve()
    out_dir = Path(args.out).expanduser().resolve()

    xmls = list_xmls(anno_root)
    total_objects, records = iterate_objects(xmls, images_root)
    print(f"[INFO] Parsed {len(xmls)} XMLs, total objects = {total_objects}")

    train_indices_full = read_split_indices(splits_dir, "train")
    test_indices_full = read_split_indices(splits_dir, "test")

    train_indices = sample_indices(train_indices_full, args.sample_ratio, args.sample_seed, args.sample_mode)
    test_indices = sample_indices(test_indices_full, args.sample_ratio, args.sample_seed, args.sample_mode)

    print(f"[INFO] Sampling train: {len(train_indices_full)} -> {len(train_indices)}")
    print(f"[INFO] Sampling val(test): {len(test_indices_full)} -> {len(test_indices)}")

    train_jsonl = out_dir / "train.jsonl"
    train_img_dir = out_dir / "images" / "train"
    ensure_dir(train_img_dir)
    kept_train = convert_split(records, train_indices, train_jsonl, args.copy_images,
                               train_img_dir, args.decimals,
                               think_words_min=args.think_words_min,
                               think_words_max=args.think_words_max,
                               wait_min=args.wait_min, wait_max=args.wait_max,
                               rng=ctrl_rng)
    print(f"[OK] train: wrote {kept_train} samples -> {train_jsonl}")

    val_jsonl = out_dir / "val.jsonl"
    val_img_dir = out_dir / "images" / "val"
    ensure_dir(val_img_dir)
    kept_val = convert_split(records, test_indices, val_jsonl, args.copy_images,
                             val_img_dir, args.decimals,
                             think_words_min=args.think_words_min,
                             think_words_max=args.think_words_max,
                             wait_min=args.wait_min, wait_max=args.wait_max,
                             rng=ctrl_rng)
    print(f"[OK] val:   wrote {kept_val} samples -> {val_jsonl}")

    print("\nDone. Example usage:")
    print(f"  data.train_files={out_dir.as_posix()}/train.jsonl \\")
    print(f"  data.val_files={out_dir.as_posix()}/val.jsonl \\")
    print("  data.image_dir=null")
    print("  data.prompt_key=problem")
    print("  data.answer_key=answer  # ground_truth will be this dict")
    print("  data.image_key=images")
    print("  # ground_truth schema (answer): {{'bbox': [x1,y1,x2,y2], 'think_words': W, 'wait_repeats': K, 'think_opening': O}}")
    print(f"  # Control ranges: think_words in [{args.think_words_min},{args.think_words_max}], "
          f"wait_repeats in [{args.wait_min},{args.wait_max}], seed={control_seed}")

if __name__ == "__main__":
    main()
