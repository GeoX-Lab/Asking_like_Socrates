#!/bin/bash

python3 convert_clevr_to_jsonl.py \
    --src "../../geometry3k/geometry3k" \
    --out "../../geometry3k_json"

