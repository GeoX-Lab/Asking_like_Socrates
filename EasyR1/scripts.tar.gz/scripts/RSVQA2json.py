#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Multi-GPU batch builder for multi-select VQA options (DeepSeek-R1-Distill-Qwen-7B) + Qwen3-8B verifier
+ Per-option CSV logging

• 生成：主进程切“图→组”派发到各GPU工作进程；每组在对应GPU上批量生成（每QA一条）
• 校验：主进程加载 Qwen3-8B，批量判定每个选项是否满足要求（输出 Yes/No）
       - 判定为 No 的选项直接删除，同时删除对应 want_true
       - 删除后如组不满足约束（长度 < MIN_GROUP 或不含真/假其一），丢弃该组
• 断点续做：以 IMG_DIR 中已有 img_XXXX.jpg 为已完成图片，整张跳过
• 进度条：图片级总进度 + 每图片内组进度
• CSV：记录每一个被校验的选项（题目、答案、生成的选项、该选项设定正确与否、校验判断 Yes/No）
"""

import os, io, json, random, re, hashlib, queue, csv
from typing import List, Dict, Any, Optional
from statistics import mean
from datasets import load_dataset
from PIL import Image
import torch
from tqdm import tqdm
import multiprocessing as mp

# ================= Fixed config =================
DATA_GLOB = "/g0001sr/lzy/RSVQA-HR_qwen_finetuning/data/train-*.parquet"
GROUP_SIZE_PER_IMAGE = 100
N_GROUPS_PER_IMAGE = 12
MIN_GROUP = 5
MAX_GROUP = 12
N_IMAGES_TO_PROCESS = 1000
SEED = 42

OUTDIR = "/g0001sr/lzy/RSVQA-HR-json"
IMG_DIR = os.path.join(OUTDIR, "images")
JSONL_PATH = os.path.join(OUTDIR, "train.jsonl")
CSV_PATH = os.path.join(OUTDIR, "verify_log.csv")  # 新增：逐选项校验日志

# ===== Generator model =====
DEEPSEEK_ID = "/g0001sr/model_weights/DeepSeek-R1-Distill-Qwen-7B"
GEN_MAX_NEW_TOKENS = 256
GEN_TEMPERATURE = 0.9
GEN_TOP_P = 0.95
USE_FLASH_ATTENTION_2 = True

# ===== Verifier model (Qwen3-8B) =====
VERIFIER_ID = "/g0001sr/model_weights/Qwen3-8B"   # 按你的实际路径修改
VERIFIER_MAX_NEW_TOKENS = 8
# 若为 None：自动挑选不被工作进程占用的GPU；给整数如 2 可固定到 cuda:2；给 -1 则强制CPU
VERIFIER_GPU_ID = 0

# ===== GPU 并行参数（生成端）=====
GPU_IDS = None  # None -> 自动 [0..torch.cuda.device_count()-1]
TASK_QUEUE_MAXSIZE = 64

random.seed(SEED)
os.makedirs(OUTDIR, exist_ok=True)
os.makedirs(IMG_DIR, exist_ok=True)

# ================= Helpers (shared) =================
m2_pat = re.compile(r"^\s*([-+]?\d+(?:\.\d+)?)\s*m2\s*$", re.IGNORECASE)
answer_tag_pat = re.compile(r"<\s*answer\s*>([\s\S]*?)<\s*\/\s*answer\s*>", re.IGNORECASE)
IMG_NAME_RE = re.compile(r"^img_(\d{4})\.jpg$")

def uid_from_img(img: Image.Image) -> str:
    path = getattr(img, "filename", None)
    if path: return os.path.basename(path)
    buf = io.BytesIO(); img.convert("RGB").save(buf, format="PNG")
    return "sha1:" + hashlib.sha1(buf.getvalue()).hexdigest()

def save_image_once(img: Image.Image, image_index: int) -> str:
    name = f"img_{image_index:04d}.jpg"
    path = os.path.join(IMG_DIR, name)
    img.convert("RGB").save(path, format="JPEG")
    return os.path.abspath(path)

def presence_truth_from_answer(answer: str) -> Optional[bool]:
    a = str(answer).strip()
    m = m2_pat.match(a)
    if not m: return None
    val = float(m.group(1))
    return (val != 0.0)

def build_prompt(question: str, answer: str, want_true: bool, presence_truth: Optional[bool]) -> str:
    base_rule = (
        "You are a generator of multiple-choice option statements for visual question answering (VQA).\n"
        "Given a VQA question and its gold answer, produce ONE concise English statement (<= 25 words) "
        "that will be used as an option in a multi-select question. "
        "Strictly follow this output format: put your reasoning in <think>...</think>, "
        "and put ONLY the final statement in <answer>...</answer>. Do not add quotes or numbering."
    )
    if presence_truth is None:
        correctness = "CORRECT" if want_true else "INCORRECT"
        rule = (
            f"For THIS option, it must be {correctness}.\n"
            "If CORRECT, the statement MUST be logically consistent with the (question, answer).\n"
            "If INCORRECT, the statement MUST contradict or clearly conflict with the (question, answer)."
        )
    else:
        true_text = "PRESENT" if presence_truth else "NOT PRESENT"
        rule = (
            "AREA RULE: If the gold answer is '0m2', the target is NOT PRESENT in the image; "
            "if the gold answer is '<non-zero>m2', the target is PRESENT in the image.\n"
            f"For THIS case, the truth is: {true_text}.\n"
        )
        if want_true:
            rule += (
                "Generate a statement CONSISTENT with this truth: "
                "if truth is PRESENT, assert that the target is present; if truth is NOT PRESENT, assert that it is absent."
            )
        else:
            rule += (
                "Generate a statement CONTRADICTING this truth: "
                "if truth is PRESENT, assert that the target is absent; if truth is NOT PRESENT, assert that it is present."
            )
        rule += (
            "\nExtract the target noun phrase from the question (e.g., 'nature reserve', 'road'). "
            "Do NOT output any numbers; make a pure presence/absence statement."
        )
    q = question.strip()
    a = str(answer).strip()
    prompt = (
        f"{base_rule}\n\n{rule}\n\n"
        f"Question: {q}\n"
        f"Gold Answer: {a}\n"
        "Respond EXACTLY in this structure:\nDon't say Yes or No in your answer!\n"
        "<think>your brief reasoning</think>\n"
        "<answer>your single concise English statement</answer>\n"
    )
    return prompt

def extract_answer(text: str) -> str:
    matches = list(answer_tag_pat.finditer(text))
    if matches:
        return matches[-1].group(1).strip()
    for line in reversed(text.strip().splitlines()):
        if line.strip():
            return re.sub(r"</?answer>", "", line.strip(), flags=re.I)
    return "Unparseable output"

def cleanup_answer(s: str) -> str:
    s = re.sub(r"</?\s*answer\s*>", "", s, flags=re.IGNORECASE).strip()
    s = s.strip().strip('"').strip("'").strip('`')
    s = re.sub(r"\s+", " ", s)
    return s

def split_100_into_20_once(min_g: int, max_g: int, n_groups: int, total: int) -> List[int]:
    n, target = n_groups, total
    sizes = [random.randint(min_g, max_g) for _ in range(n)]
    s = sum(sizes)
    while s != target:
        if s > target:
            idxs = [i for i,v in enumerate(sizes) if v > min_g]
            if not idxs: sizes = [min_g]*n; s = sum(sizes); continue
            i = random.choice(idxs); sizes[i]-=1; s-=1
        else:
            idxs = [i for i,v in enumerate(sizes) if v < max_g]
            if not idxs: sizes = [max_g]*n; s = sum(sizes); continue
            i = random.choice(idxs); sizes[i]+=1; s+=1
    return sizes

SIZES_PATTERN = split_100_into_20_once(MIN_GROUP, MAX_GROUP, N_GROUPS_PER_IMAGE, GROUP_SIZE_PER_IMAGE)

WANTS_TEMPLATES: Dict[int, List[bool]] = {}
def wants_for_len(L: int) -> List[bool]:
    if L not in WANTS_TEMPLATES:
        w = [bool(random.getrandbits(1)) for _ in range(L)]
        if all(w):        w[random.randrange(L)] = False
        elif not any(w):  w[random.randrange(L)] = True
        WANTS_TEMPLATES[L] = w
    return WANTS_TEMPLATES[L]

def rotate_pattern(seq: List[Any], k: int) -> List[Any]:
    k %= len(seq);  return seq[k:] + seq[:k]

def load_done_image_indices(img_dir: str) -> set:
    done = set()
    try:
        for fn in os.listdir(img_dir):
            m = IMG_NAME_RE.match(fn)
            if m:
                done.add(int(m.group(1)))
    except FileNotFoundError:
        pass
    return done

# ================= Worker process (generator) =================
def _slice_and_decode_batch(tokenizer, input_ids, generated_ids):
    pad_id = tokenizer.pad_token_id
    if pad_id is None:
        in_lens = [ids.size(0) for ids in input_ids]
    else:
        in_lens = (input_ids != pad_id).sum(dim=1).tolist()
    texts = []
    for i in range(generated_ids.size(0)):
        new_ids = generated_ids[i, in_lens[i]:]
        texts.append(tokenizer.decode(new_ids, skip_special_tokens=True))
    return texts

def worker_loop(gpu_id: int, task_q: mp.Queue, result_q: mp.Queue,
                model_id: str, max_new_tokens: int,
                temperature: float, top_p: float, use_fa2: bool):
    # 限定子进程只见到一张卡
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id)
    torch.cuda.set_device(0)

    from transformers import AutoTokenizer, AutoModelForCausalLM
    tok = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "left"

    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        torch_dtype="auto",
        device_map={"": 0},   # 仅用到本进程可见的 cuda:0
        trust_remote_code=True,
        attn_implementation=("flash_attention_2" if use_fa2 else "eager"),
    )

    while True:
        task = task_q.get()
        if task is None:
            break

        try:
            qs   = task["questions"]
            ans  = task["answers"]
            wants= task["wants"]
            pres = [presence_truth_from_answer(a) for a in ans]

            prompts = [build_prompt(q, a, w, p) for q,a,w,p in zip(qs, ans, wants, pres)]
            enc = tok(prompts, return_tensors="pt", padding=True, truncation=False)
            enc = {k: v.to(model.device) for k,v in enc.items()}

            with torch.no_grad():
                out = model.generate(
                    enc["input_ids"],
                    attention_mask=enc.get("attention_mask", None),
                    max_new_tokens=max_new_tokens,
                    do_sample=True,
                    temperature=temperature,
                    top_p=top_p,
                    pad_token_id=tok.pad_token_id,
                )
            dec = _slice_and_decode_batch(tok, enc["input_ids"], out)
            options = [cleanup_answer(extract_answer(t).strip()) if t else "Unparseable output" for t in dec]

            result_q.put({
                "image_index": task["image_index"],
                "group_index": task["group_index"],
                "options": options,
                "wants": wants,
                "answers": ans,          # 校验要用到 gold answer
                "questions": qs,         # 校验要用到 question
            })

        except Exception as e:
            result_q.put({
                "image_index": task.get("image_index", -1),
                "group_index": task.get("group_index", -1),
                "error": f"{type(e).__name__}: {e}",
            })

# ================= Verifier (Qwen3-8B, main process) =================
def _pick_verifier_device(verifier_gpu_id: Optional[int], worker_gpu_ids: List[int]) -> str:
    if verifier_gpu_id == -1:
        return "cpu"
    if torch.cuda.is_available():
        if verifier_gpu_id is None:
            # 自动挑未被工作进程占用的卡
            all_ids = list(range(torch.cuda.device_count()))
            free = [g for g in all_ids if g not in worker_gpu_ids]
            if free:
                return f"cuda:{free[0]}"
            else:
                return "cpu"
        else:
            return f"cuda:{verifier_gpu_id}"
    return "cpu"

def build_verifier_prompt(question: str,
                          gold_answer: str,
                          statement: str,
                          want_true: bool,
                          presence_truth: Optional[bool]) -> str:
    rule = [
        "You are a strict verifier for multi-select VQA options.",
        "Given (Question, Gold Answer) and a CANDIDATE STATEMENT, decide if the statement satisfies the REQUIRED correctness.",
        "Output strictly one word inside <answer>...</answer>: Yes or No. No other text."
    ]
    if presence_truth is None:
        req = "REQUIRED: If want_true=True the statement must be logically CONSISTENT with (Question, Gold Answer); otherwise it must CONTRADICT them."
    else:
        true_text = "PRESENT" if presence_truth else "NOT PRESENT"
        req = (
            "AREA RULE: If Gold Answer is '0m2' => NOT PRESENT; '<nonzero>m2' => PRESENT. "
            f"Truth for this case: {true_text}. "
            "REQUIRED: If want_true=True, the statement must be consistent with this truth; else it must contradict it."
        )
    want = f"want_true={str(want_true)}"
    prompt = (
        "\n".join(rule) + "\n\n"
        f"{req}\n\n"
        f"Question: {question.strip()}\n"
        f"Gold Answer: {str(gold_answer).strip()}\n"
        f"Candidate Statement: {statement.strip()}\n"
        f"{want}\n\n"
        "Output:\n<answer>Yes</answer>  or  <answer>No</answer>\n"
    )
    return prompt

def load_verifier(verifier_id: str, device: str):
    from transformers import AutoTokenizer, AutoModelForCausalLM
    tok = AutoTokenizer.from_pretrained(verifier_id, trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "left"

    device_map = {"": "cpu"} if device == "cpu" else {"": int(device.split(":")[1])}
    ver_model = AutoModelForCausalLM.from_pretrained(
        verifier_id,
        torch_dtype="auto",
        device_map=device_map,
        trust_remote_code=True,
        attn_implementation="eager",
    )
    ver_model.generation_config.pad_token_id = tok.pad_token_id
    return tok, ver_model

_yesno_pat = re.compile(r"<\s*answer\s*>\s*(yes|no)\s*<\s*/\s*answer\s*>", re.IGNORECASE)

def batch_verify_qwen3(ver_tok, ver_model,
                       questions: List[str],
                       answers: List[str],
                       statements: List[str],
                       wants: List[bool]) -> List[bool]:
    """返回每个 statement 是否通过（True=Yes；False=No）"""
    prompts = []
    pres_list = [presence_truth_from_answer(a) for a in answers]
    for q,a,s,w,p in zip(questions, answers, statements, wants, pres_list):
        prompts.append(build_verifier_prompt(q, a, s, w, p))

    enc = ver_tok(prompts, return_tensors="pt", padding=True)
    device = ver_model.device
    enc = {k: v.to(device) for k,v in enc.items()}

    with torch.inference_mode():
        outs = ver_model.generate(
            enc["input_ids"],
            attention_mask=enc.get("attention_mask", None),
            max_new_tokens=VERIFIER_MAX_NEW_TOKENS,
            #do_sample=False,
            pad_token_id=ver_tok.pad_token_id,
        )

    pad_id = ver_tok.pad_token_id
    if pad_id is None:
        in_lens = [ids.size(0) for ids in enc["input_ids"]]
    else:
        in_lens = (enc["input_ids"] != pad_id).sum(dim=1).tolist()

    verdicts = []
    for i in range(outs.size(0)):
        gen_piece = outs[i, in_lens[i]:]
        txt = ver_tok.decode(gen_piece, skip_special_tokens=True)
        m = _yesno_pat.search(txt)
        verdicts.append(bool(m and m.group(1).lower() == "yes"))
    return verdicts

# ================= CSV helper =================
CSV_HEADER = [
    "image_index", "group_index", "option_index",
    "question", "answer", "option",
    "intended",       # "correct" or "incorrect" (from wants)
    "judged"          # "Yes" or "No" (from verifier)
]

def ensure_csv_header(path: str):
    need_header = (not os.path.exists(path)) or (os.path.getsize(path) == 0)
    if need_header:
        with open(path, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(CSV_HEADER)

def append_option_rows(path: str,
                       image_index: int,
                       group_index: int,
                       questions: List[str],
                       answers: List[str],
                       options: List[str],
                       wants: List[bool],
                       verdicts: List[bool]):
    # 将每个选项逐行写入
    with open(path, "a", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        for i, (q, a, opt, w, v) in enumerate(zip(questions, answers, options, wants, verdicts)):
            writer.writerow([
                image_index,
                group_index,
                i,
                q,
                a,
                opt,
                "correct" if w else "incorrect",
                "Yes" if v else "No"
            ])

# ================= Main =================
def main():
    # —— 断点续做：读取已完成的图片索引
    done_indices = load_done_image_indices(IMG_DIR)
    done_count = len(done_indices)
    if done_count:
        print(f"[Resume] Found {done_count} finished images in {IMG_DIR}. Will skip those indices.")

    # —— 生成端 GPU
    if GPU_IDS is None:
        n = torch.cuda.device_count()
        if n == 0:
            raise RuntimeError("No CUDA devices found. Please run on a GPU machine.")
        gpu_ids = list(range(n))
    else:
        gpu_ids = list(GPU_IDS)

    # —— 启动生成端 worker（每GPU一进程）
    ctx = mp.get_context("spawn")
    task_queues = []
    result_queue = ctx.Queue()
    workers = []
    for gid in gpu_ids:
        tq = ctx.Queue(maxsize=TASK_QUEUE_MAXSIZE)
        p = ctx.Process(
            target=worker_loop,
            args=(gid, tq, result_queue, DEEPSEEK_ID, GEN_MAX_NEW_TOKENS, GEN_TEMPERATURE, GEN_TOP_P, USE_FLASH_ATTENTION_2),
            daemon=True
        )
        p.start()
        task_queues.append(tq)
        workers.append(p)

    # —— 校验端（主进程加载 Qwen3-8B）
    ver_device = _pick_verifier_device(VERIFIER_GPU_ID, gpu_ids)
    print(f"[Verifier] Loading Qwen3-8B on {ver_device} ...")
    ver_tok, ver_model = load_verifier(VERIFIER_ID, ver_device)
    print("[Verifier] Ready.")

    # —— CSV 初始化
    ensure_csv_header(CSV_PATH)

    def dispatch_tasks(group_tasks: List[Dict[str, Any]]):
        rr = 0
        for t in group_tasks:
            task_queues[rr % len(task_queues)].put(t)
            rr += 1

    ds = load_dataset("parquet", data_files={"train": DATA_GLOB}, split="train", streaming=True)
    it = iter(ds)

    image_index = 0
    written_groups_total = 0
    processed_images = 0

    total_target = N_IMAGES_TO_PROCESS if N_IMAGES_TO_PROCESS is not None else None
    initial_done = min(done_count, total_target) if total_target is not None else done_count

    # 以追加模式写 JSONL
    with open(JSONL_PATH, "a", encoding="utf-8") as fout, \
         tqdm(total=total_target, initial=initial_done, desc="Images", unit="img") as pbar:

        processed_images = done_count

        while True:
            if total_target is not None and processed_images >= total_target:
                break

            block = _read_one_image_block(it)
            if not block:
                break
            image_index += 1

            # 已做过的图片整体跳过
            if image_index in done_indices:
                pbar.update(1)
                processed_images += 1
                continue

            img_path = save_image_once(block[0]["image"], image_index)

            # 分组
            sizes = rotate_pattern(SIZES_PATTERN, k=image_index % len(SIZES_PATTERN))
            groups = []
            start = 0
            for s in sizes:
                g = block[start:start+s]
                if g:
                    groups.append(g)
                start += s

            # 组任务
            group_tasks = []
            for gi, g in enumerate(groups):
                L = len(g)
                wants = rotate_pattern(wants_for_len(L), k=image_index % max(L,1)) if L > 1 else wants_for_len(L)
                q_list = [str(qa["question"]).strip() for qa in g]
                a_list = [str(qa["answer"]).strip()   for qa in g]
                group_tasks.append({
                    "image_index": image_index,
                    "group_index": gi,
                    "questions": q_list,
                    "answers": a_list,
                    "wants": wants,
                })

            # 派发 + 回收 + 校验 + 落盘
            dispatch_tasks(group_tasks)

            with tqdm(total=len(group_tasks), desc=f"Image {image_index:04d} groups", leave=False, unit="group") as gpbar:
                received = 0
                while received < len(group_tasks):
                    try:
                        res = result_queue.get(timeout=600)
                    except queue.Empty:
                        continue
                    received += 1
                    gpbar.update(1)

                    if "error" in res:
                        continue

                    gi = res["group_index"]
                    wants     = res["wants"]
                    options   = res["options"]
                    questions = res["questions"]
                    answers   = res["answers"]

                    # === 批量校验（Qwen3-8B）===
                    verdict_bools = batch_verify_qwen3(ver_tok, ver_model, questions, answers, options, wants)
                    # —— 先把全部校验结果写入 CSV（日后可回溯）
                    append_option_rows(
                        CSV_PATH,
                        image_index=image_index,
                        group_index=gi,
                        questions=questions,
                        answers=answers,
                        options=options,
                        wants=wants,
                        verdicts=verdict_bools
                    )

                    # —— 按校验结果过滤
                    keep_mask = verdict_bools
                    filt_options = [opt for opt, keep in zip(options, keep_mask) if keep]
                    filt_wants   = [w   for w,   keep in zip(wants,   keep_mask) if keep]

                    # 过滤后组级约束
                    if len(filt_options) < MIN_GROUP:
                        continue
                    labels = [i for i, w in enumerate(filt_wants) if w]
                    has_true = len(labels) > 0
                    has_false = len(labels) < len(filt_options)
                    if not (has_true and has_false):
                        continue

                    rec = {
                        "image": img_path,
                        "options": filt_options,
                        "labels": labels,
                        "meta": {
                            "image_index": image_index,
                            "group_index": gi,
                            "group_size": len(filt_options),
                            "filtered": {
                                "original": len(options),
                                "kept": len(filt_options)
                            }
                        }
                    }
                    fout.write(json.dumps(rec, ensure_ascii=False) + "\n")
                    written_groups_total += 1

            print(f"[Image {image_index:04d}] groups mean={mean([len(g) for g in groups]):.2f} "
                  f"min={min(len(g) for g in groups)} max={max(len(g) for g in groups)} -> examples {len(groups)}")

            pbar.update(1)
            processed_images += 1

    # 优雅关闭workers
    for tq in task_queues:
        tq.put(None)
    for p in workers:
        p.join(timeout=30)

    print("\n=== DONE ===")
    print(f"images processed (this run + previous): {processed_images}")
    print(f"groups written (this run): {written_groups_total}")
    print(f"images dir: {os.path.abspath(IMG_DIR)}")
    print(f"train.jsonl (appended): {os.path.abspath(JSONL_PATH)}")
    print(f"verify csv: {os.path.abspath(CSV_PATH)}")

def _read_one_image_block(it):
    """读取同一张图的连续样本，凑够 GROUP_SIZE_PER_IMAGE 或到下一张图为止。"""
    try:
        first = next(it)
    except StopIteration:
        return None
    block = [first]
    base_uid = uid_from_img(first["image"])
    while len(block) < GROUP_SIZE_PER_IMAGE:
        ex = next(it, None)
        if ex is None:
            break
        if uid_from_img(ex["image"]) != base_uid:
            break
        block.append(ex)
    return block

if __name__ == "__main__":
    main()
