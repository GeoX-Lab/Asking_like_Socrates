#!/bin/bash
# 运行 RSVG -> JSONL 导出器

# 配置路径，根据你的实际目录修改
IMAGES_DIR="/g0001sr/lzy/DIOR_RSVG/JPEGImages"
ANNOS_DIR="/g0001sr/lzy/DIOR_RSVG/Annotations"
SPLITS_DIR="/g0001sr/lzy/DIOR_RSVG/"
OUT_DIR="/g0001sr/lzy/DIOR_RSVG_jsonl_NEW/"

# 是否复制图片（默认 direct-link），加上 --copy-images 就会把图片复制到 OUT_DIR/images/
COPY_FLAG="--copy-images"

# 执行
python3 /g0001sr/lzy/EasyR1/scripts/RSVG2json.py \
  --images "$IMAGES_DIR" \
  --annos "$ANNOS_DIR" \
  --splits "$SPLITS_DIR" \
  --out "$OUT_DIR" \
  $COPY_FLAG
