import re
import math
from typing import Any, Optional, Sequence, Tuple, List, Dict

_NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"

# -------------------- Parsing: ONLY from \boxed{...} --------------------

def _extract_boxed(text: str) -> Optional[str]:
    """Return content inside \boxed{...}; None if absent."""
    m = re.search(r"\\boxed\{\s*(.*?)\s*\}", text, flags=re.DOTALL)
    return m.group(1) if m else None

def _parse_four_floats_0_1(text: str) -> Optional[List[float]]:
    """Parse the FIRST four floats in [0,1] from text."""
    nums = re.findall(_NUMBER, text)
    if len(nums) < 4:
        return None
    vals: List[float] = []
    for s in nums[:4]:
        try:
            v = float(s)
        except Exception:
            return None
        if not (0.0 <= v <= 1.0):
            return None
        vals.append(v)
    return vals if len(vals) == 4 else None

def _parse_box_from_response_boxed_only(response: str) -> Optional[List[float]]:
    """Must parse from inside \boxed{...}; otherwise None."""
    inner = _extract_boxed(response)
    if inner is None:
        return None
    return _parse_four_floats_0_1(inner)

def _parse_box_from_gt(gt: Any) -> List[float]:
    """
    解析 ground truth 框：
      - list/tuple: 必须长度 4，且值在 [0,1]
      - numpy.ndarray: 取前 4 个元素（一维化），必须长度 4，且值在 [0,1]
      - str: 尝试解析 4 个 [0,1] 内的浮点数
      - 其他类型：报错

    任意不满足条件 -> 抛出异常，避免 silent fail。
    """
    # ---- numpy.ndarray 支持 ----
    try:
        import numpy as np  # 延迟导入，避免硬依赖
        if isinstance(gt, np.ndarray):
            flat = gt.astype(float).reshape(-1)  # 展平成一维
            if flat.size < 4:
                raise ValueError(f"Ground truth ndarray must contain at least 4 elements, got {flat.size}: {gt}")
            vals = flat[:4].tolist()
            if not all(math.isfinite(v) for v in vals):
                raise ValueError(f"Ground truth ndarray contains non-finite values: {vals}")
            if not all(0.0 <= v <= 1.0 for v in vals):
                raise ValueError(f"Ground truth ndarray values must be in [0,1], got {vals}")
            return vals
    except ImportError:
        pass  # 若环境无 numpy，则跳过 ndarray 分支（下方会继续类型判断）

    # ---- list / tuple ----
    if isinstance(gt, (list, tuple)):
        if len(gt) != 4:
            raise ValueError(f"Ground truth must have 4 elements, got {len(gt)}: {gt}")
        vals = [float(v) for v in gt]
        if not all(math.isfinite(v) for v in vals):
            raise ValueError(f"Ground truth contains non-finite values: {vals}")
        if not all(0.0 <= v <= 1.0 for v in vals):
            raise ValueError(f"Ground truth values must be in [0,1], got {vals}")
        return vals

    # ---- string ----
    if isinstance(gt, str):
        vals = _parse_four_floats_0_1(gt)
        if vals is None:
            raise ValueError(f"Could not parse 4 floats in [0,1] from GT string: {gt}")
        return vals

    # ---- 其他不支持 ----
    raise TypeError(f"Unsupported GT type: {type(gt)}, value={gt}")

# -------------------- Geometry & IoU --------------------

def _fix_and_clip_box_xyxy01(box: Sequence[float]) -> Tuple[float, float, float, float]:
    """Ensure (x1<=x2, y1<=y2) and clip to [0,1]."""
    x1, y1, x2, y2 = box
    if x2 < x1:
        x1, x2 = x2, x1
    if y2 < y1:
        y1, y2 = y2, y1
    x1 = max(0.0, min(1.0, x1))
    y1 = max(0.0, min(1.0, y1))
    x2 = max(0.0, min(1.0, x2))
    y2 = max(0.0, min(1.0, y2))
    return x1, y1, x2, y2

def _iou_xyxy01(a: Sequence[float], b: Sequence[float]) -> float:
    ax1, ay1, ax2, ay2 = _fix_and_clip_box_xyxy01(a)
    bx1, by1, bx2, by2 = _fix_and_clip_box_xyxy01(b)
    iw = max(0.0, min(ax2, bx2) - max(ax1, bx1))
    ih = max(0.0, min(ay2, by2) - max(ay1, by1))
    inter = iw * ih
    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    union = area_a + area_b - inter
    return 0.0 if union <= 0.0 else inter / union

def _center_distance_xyxy01(a: Sequence[float], b: Sequence[float]) -> float:
    """Euclidean distance between centers of two clipped boxes in [0,1]^2."""
    ax1, ay1, ax2, ay2 = _fix_and_clip_box_xyxy01(a)
    bx1, by1, bx2, by2 = _fix_and_clip_box_xyxy01(b)
    acx = 0.5 * (ax1 + ax2); acy = 0.5 * (ay1 + ay2)
    bcx = 0.5 * (bx1 + bx2); bcy = 0.5 * (by1 + by2)
    return math.hypot(acx - bcx, acy - bcy)

def _half_diagonal_length_xyxy01(box: Sequence[float]) -> float:
    """Half of the diagonal length of a clipped GT box (in normalized units)."""
    x1, y1, x2, y2 = _fix_and_clip_box_xyxy01(box)
    diag = math.hypot(x2 - x1, y2 - y1)  # full diagonal
    return 0.5 * diag

# -------------------- Rewards --------------------

def format_reward(response: str) -> float:
    """
    格式奖励（可选）：必须包含 <think>...</think> 且 \boxed{...} 内能解析 4 个 0-1 浮点数。
    若你不需要 <think> 约束，可改 think_ok=True。
    """
    think_ok = bool(re.search(r"<think>.*?</think>", response, flags=re.DOTALL))
    boxed_inner = _extract_boxed(response)
    boxed_ok = boxed_inner is not None and (_parse_four_floats_0_1(boxed_inner) is not None)
    return 1.0 if (think_ok and boxed_ok) else 0.0

def accuracy_reward_boxes(
    response: str,
    ground_truth: Any,
) -> float:
    """
    纯 IoU 准确度（从 \\boxed{...} 中读取预测框）：
        acc = IoU(pred, gt)
    解析失败返回 0.0
    """
    pred = _parse_box_from_response_boxed_only(response)
    gt = _parse_box_from_gt(ground_truth)
    if pred is None or gt is None:
        return 0.0
    return _iou_xyxy01(pred, gt)


def compute_score(
    reward_inputs: List[Dict[str, Any]],
    format_weight: float = 0.1,  # 保留格式奖励权重
) -> List[Dict[str, float]]:
    """
    批量评估：
      - format: 是否满足 <think>...</think> 且 \boxed{...} 可解析 → {0,1}
      - accuracy: 纯 IoU（[0,1]）
      - overall = (1 - format_weight) * accuracy + format_weight * format
    """
    if not isinstance(reward_inputs, list):
        raise ValueError("Please use `reward_type=batch` for boxes reward function.")

    results: List[Dict[str, float]] = []
    for item in reward_inputs:
        # 收敛尖括号空格
        response = re.sub(r"\s*(<|>|/)\s*", r"\1", str(item["response"]))
        gt = item["ground_truth"]

        fmt = format_reward(response)          # 0/1
        acc = accuracy_reward_boxes(response, gt)  # 纯 IoU
        overall = (1.0 - format_weight) * acc + format_weight * fmt

        results.append({
            "overall": overall,
            "format": fmt,
            "accuracy": acc,
        })
    return results

